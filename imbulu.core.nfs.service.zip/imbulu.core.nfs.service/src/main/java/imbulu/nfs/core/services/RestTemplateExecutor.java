package imbulu.nfs.core.services;

import java.util.concurrent.CompletableFuture;
import javax.net.ssl.HostnameVerifier;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Service
public class RestTemplateExecutor {
  private static final Logger log = LoggerFactory.getLogger(imbulu.nfs.core.services.RestTemplateExecutor.class);
  
  @Async
  public CompletableFuture<String> httpPost(String message, String url, HttpHeaders httpHeaders) {
    HttpEntity<Object> entity = new HttpEntity(message, (MultiValueMap)httpHeaders);
    RestTemplate restTemplate = new RestTemplate((ClientHttpRequestFactory)customHttpRequestFactory());
    return processPostRequest(restTemplate, url, entity);
  }
  
  @Async
  public CompletableFuture<String> httpPostMultiple(MultiValueMap<String, String> data, String url) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
    HttpEntity<MultiValueMap<String, String>> request = new HttpEntity(data, (MultiValueMap)headers);
    RestTemplate restTemplate = new RestTemplate((ClientHttpRequestFactory)customHttpRequestFactory());
    return processPostRequest(restTemplate, url, request);
  }
  
  private CompletableFuture<String> processPostRequest(RestTemplate restTemplate, String url, HttpEntity request) {
    String response = "";
    try {
      ResponseEntity<String> httpresponse = restTemplate.postForEntity(url, request, String.class, new Object[0]);
      response = (String)httpresponse.getBody();
    } catch (HttpClientErrorException ex) {
      response = ex.getResponseBodyAsString();
      if (response.equals("")) {
        exception(url, "HttpClientErrorException::" + response, ex.getMessage());
      } else {
        exception(url, response, ex.getMessage());
      } 
    } catch (HttpStatusCodeException ex) {
      response = ex.getResponseBodyAsString();
      exception(url, "  HttpStatusCodeException::" + response, ex.getMessage());
    } catch (RestClientException ex) {
      exception(url, "RestClientException::" + request, ex.getMessage());
    } 
    return CompletableFuture.completedFuture(response);
  }
  
  private HttpComponentsClientHttpRequestFactory customHttpRequestFactory() {
    CloseableHttpClient httpClient = HttpClients.custom().setSSLHostnameVerifier((HostnameVerifier)new NoopHostnameVerifier()).build();
    HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
    requestFactory.setHttpClient((HttpClient)httpClient);
    requestFactory.setReadTimeout(50000);
    requestFactory.setConnectTimeout(50000);
    return requestFactory;
  }
  
  @Async
  public CompletableFuture<String> httpExchange(String message, String url, HttpHeaders httpHeaders, HttpMethod httpMethod, String messageToLog) {
    log.info("CPGrequest: {} {}", url, messageToLog);
    String response = "";
    try {
      RestTemplate restTemplate = new RestTemplate((ClientHttpRequestFactory)customHttpRequestFactory());
      HttpEntity<String> entity = new HttpEntity(message, (MultiValueMap)httpHeaders);
      ResponseEntity<String> result = restTemplate.exchange(url, httpMethod, entity, String.class, new Object[0]);
      response = (String)result.getBody();
      log.info("CPGresponse: {} {}", url, response);
    } catch (HttpClientErrorException ex) {
      response = ex.getResponseBodyAsString();
      exception(url, "HttpClientErrorException: " + response, ex.getMessage());
    } catch (HttpStatusCodeException ex2) {
      response = ex2.getResponseBodyAsString();
      exception(url, "HttpStatusCodeException: " + response, ex2.getMessage());
    } catch (RestClientException ex3) {
      exception(url, message, ex3.getMessage());
    } 
    return CompletableFuture.completedFuture(response);
  }
  
  public void exception(String url, String data, String exception) {
    log.error("ERROR::{} {} {}", new Object[] { url, data, exception });
  }
}
