package imbulu.nfs.core.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TimeZone;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.jpos.core.Configuration;
import org.jpos.core.SimpleConfiguration;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.packager.GenericPackager;
import org.jpos.tlv.TLVList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.primitives.Bytes;
import com.google.gson.Gson;

import imbulu.nfs.core.client.Packager;
import imbulu.nfs.core.nfs.Config;
import imbulu.nfs.core.pojos.ISOFields;

@Service
public class Utils {
	private static final Logger logger = LoggerFactory.getLogger(imbulu.nfs.core.services.Utils.class);

	@Autowired
	private Config config;

	@Autowired
	private Packager packager;

	public byte[] parseRequest(byte[] requestBytes) {
		byte[] headerBytes = this.config.getIsoheader().getBytes();
		String length = "00" + Integer.toHexString((Bytes.concat(new byte[][] { headerBytes, requestBytes })).length);
		byte[] lengthBytes = ISOUtil.hex2byte(length);
		return Bytes.concat(new byte[][] { lengthBytes, headerBytes, requestBytes });
	}

	public String logISOMsg(ISOMsg msg) {

		StringBuffer sb = new StringBuffer();
		try {
			String direction = (msg.getDirection() == 1) ? "INCOMING" : "OUTGOING";

			sb.append("ISO MESSAGE : " + direction + " \n");
			;
			sb.append("**************************************************\n");
			sb.append(ISOUtil.hexdump(msg.pack()));
			sb.append("**************************************************\n");
			sb.append("MTI : " + msg.getMTI() + " \n");

			for (int i = 0; i <= msg.getMaxField(); i++) {
				if (msg.hasField(i) && i > 0)
					if (i == 48) {
						if (msg.getDirection() == 1)
							sb.append("in[" + i + "] : " + ISOUtil.byte2hex(msg.getBytes(48)) + " \n");
						else
							sb.append("out[" + i + "] : " + ISOUtil.byte2hex(msg.getBytes(48)) + " \n");
					} else {
						if (msg.getDirection() == 1)
							sb.append("in[" + i + "] : " + msg.getValue(i) + " \n");
						else
							sb.append("out[" + i + "] : " + msg.getValue(i) + " \n");
					}
			}
		} catch (Exception e) {
			logger.info("ISOMsg logging exception STAN :" + msg.getString(11) + "| RRN :" + msg.getString(37)
					+ "| INSTITUTION :" + msg.getString(32) + ", Error: " + e.getMessage() + " Cause: " + e.getCause()
					+ " \n");
			logger.error("ISOMsg logging exception RRN {} Error: {} Cause: {}",
					new Object[] { msg.getString(37), e.getMessage(), e.getCause() });
			return sb.toString();
		}

		return sb.toString();
	}

	public String todayFormat(String format) {
		LocalDateTime myDateObj = LocalDateTime.now();
		DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern(format);
		return myDateObj.format(myFormatObj);
	}

	public Date dateFormat() {
		long milliseconds = System.currentTimeMillis();
		return new Date(milliseconds);
	}

	public Map<String, String> field48DataUnpack(byte[] field48) throws JsonProcessingException {
		HashMap<String, String> hashMap = new HashMap<>();
		while (field48.length > 0) {
			int total = field48.length;
			String field49 = ISOUtil.byte2hex(Arrays.copyOfRange(field48, 0, 2));
			int length = Integer.parseInt(ISOUtil.byte2hex(Arrays.copyOfRange(field48, 2, 3)), 16);
			String info = new String(Arrays.copyOfRange(field48, 3, 3 + length));
			hashMap.put(field49, info);
			field48 = Arrays.copyOfRange(field48, 3 + length, total);
		}
		return hashMap;
	}

	public byte[] generateField48Data(byte[] field48, String hexFieldTag, String data) {
		byte[] twobytes = ISOUtil.hex2byte(hexFieldTag);
		byte[] byteData = data.getBytes();
		byte[] length = ISOUtil.hex2byte(Integer.toHexString(byteData.length));
		return Bytes.concat(new byte[][] { field48, twobytes, length, byteData });
	}

	public String unFormatISOAmount(String value) {
		BigDecimal amount = new BigDecimal(value);
		BigDecimal foot = new BigDecimal(100);
		BigDecimal finalAmount = amount.divide(foot);
		return String.valueOf(finalAmount);
	}

	public String formatISOAmount(String value) {
		String finalvalue = "";
		try {
			BigDecimal amount = new BigDecimal(value);
			BigDecimal foot = new BigDecimal(100);
			BigDecimal finalAmount = amount.multiply(foot);
			finalvalue = ISOUtil.padleft(String.valueOf(finalAmount), 12, '0');
		} catch (ISOException e) {
			logger.error("ISO Amount format {} Error: {} Cause: {}",
					new Object[] { value, e.getMessage(), e.getCause() });
		}
		return finalvalue;
	}

	public GenericPackager getIsopackager() {
		SimpleConfiguration simpleConfiguration = new SimpleConfiguration();
		simpleConfiguration.put("packager-config", this.config.getPackagerconfig());
		return this.packager.getpackager((Configuration) simpleConfiguration);
	}

	public String generateRRN() {
		return getCATdatetimeAsString("yyDDD").substring(1) + getCATdatetimeAsString("HH");
	}

	public static String getUTCdatetimeAsString(String dateFormat) {
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		return sdf.format(new Date());
	}

	public static String getCATdatetimeAsString(String dateFormat) {
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		sdf.setTimeZone(TimeZone.getTimeZone("CAT"));
		return sdf.format(new Date());
	}

	public String getRandomTraceNumber() {
		int traceValue = (new Random()).nextInt(1000000);
		return String.format("%06d", new Object[] { Integer.valueOf(traceValue) });
	}

	public String createRestISO(ISOMsg isoMsg) {
		Map<String, Object> resp = new HashMap<>();
		try {
			resp.put("mti", isoMsg.getMTI());
			for (int i = 1; i <= isoMsg.getMaxField(); i++) {
				if (isoMsg.hasField(i)) {
					logger.debug("FIELD " + i + "=>" + isoMsg.getString(i));
					resp.put("f" + i, isoMsg.getString(i));
				}
			}
		} catch (ISOException e) {
			e.printStackTrace();
		}

		return new Gson().toJson(resp);
	}

	public ISOMsg getISOfromPOjo(ISOFields request) {
		ISOMsg iso = new ISOMsg();
		try {
			JSONObject jo = new JSONObject(new Gson().toJson(request));
			JSONArray name = jo.names();
			logger.debug("NUMBER OF FIELD ELEMENTS => " + jo.length());
			logger.debug("MTI => " + jo.getString("mti"));
			iso.setMTI(jo.getString("mti"));
			iso.set(0, jo.getString("mti"));
			for (int i = 0; i < jo.length(); i++) {
				if (name.get(i).toString().startsWith("f")) {
					logger.debug("FIELD " + i + "=>" + name.get(i));
					iso.set(Integer.parseInt(name.get(i).toString().replace("f", "")),
							jo.getString(name.get(i).toString()));
				}
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ISOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return iso;
	}

	public byte[] setField48Kyc(String name, String address) {
		TLVList tlvList1 = TLVList.TLVListBuilder.createInstance().fixedTagSize(2).build();
		tlvList1.append(0xA019, name.getBytes());
		tlvList1.append(0xA020, address.getBytes());
		byte[] packed1 = tlvList1.pack();
		String hexString = ISOUtil.byte2hex(packed1);
		return hexString.getBytes();
	}

	public byte[] wrappNameAddress(String name, String address) {
		logger.debug("Name :", name);
		logger.debug("Address :", address);
		byte[] bodyBytes = Bytes
				.concat(new byte[][] { generateField48Data("A019", name), generateField48Data("A020", address) });

		return bodyBytes;
	}

	public byte[] wrappNameNarration(String name, String narration) {
		logger.debug("Name :", name);
		logger.debug("Address :", narration);
		byte[] bodyBytes = Bytes
				.concat(new byte[][] { generateField48Data("C019", narration), generateField48Data("C01B", name) });

		return bodyBytes;
	}

	public byte[] wrappOTP(String otp) {
		byte[] bodyBytes = generateField48Data("A021", otp);
		return bodyBytes;
	}

	public byte[] generateField48Data(String hexFieldTag, String data) {
		byte[] twobytes = ISOUtil.hex2byte(hexFieldTag);
		byte[] byteData = data.getBytes();
		byte[] length = ISOUtil.hex2byte(Integer.toHexString(byteData.length));
		return Bytes.concat(new byte[][] { twobytes, length, byteData });
	}

	public byte[] hexStringToBytes(String hexString) {
		if (StringUtils.isEmpty(hexString)) {
			return null;
		}
		hexString = hexString.toLowerCase();
		final byte[] byteArray = new byte[hexString.length() >> 1];
		int index = 0;
		for (int i = 0; i < hexString.length(); i++) {
			if (index > hexString.length() - 1) {
				return byteArray;
			}
			byte highDit = (byte) (Character.digit(hexString.charAt(index), 16) & 0xFF);
			byte lowDit = (byte) (Character.digit(hexString.charAt(index + 1), 16) & 0xFF);
			byteArray[i] = (byte) (highDit << 4 | lowDit);
			index += 2;
		}
		return byteArray;
	}

	public ISOMsg clean(ISOMsg request) throws ISOException {

		if (request.getMTI().equals("1200") & request.getValue(3).equals("310000")) {

			if (request.hasField(5)) {
				request.unset(5);
			}
			if (request.hasField(6)) {
				request.unset(6);
			}
			if (request.hasField(10)) {
				request.unset(10);
			}
			if (request.hasField(50)) {
				request.unset(50);
			}
			if (request.hasField(51)) {
				request.unset(51);
			}
			if (request.hasField(53)) {
				request.unset(53);
			}
		}
		return request;

	}

}
