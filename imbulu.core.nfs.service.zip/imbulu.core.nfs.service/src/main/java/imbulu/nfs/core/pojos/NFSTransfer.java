package imbulu.nfs.core.pojos;

public class NFSTransfer {
	
	public String msg_type;                              
	public String pan;                                   
	public String pro_code;                              
	public String amount;                                
	public String trans_date;                            
	public String trans_time;                            
	public String conv_rate;                             
	public String stan;                                  
	public String local_date;                            
	public String local_time;                            
	public String capt_date;                             
	public String country_code;                          
	public String recon_date;                            
	public String rrn;                                   
	public String act_code;                              
	public String data;                                  
	public String add_amounts;                           
	public String acq_inst_code;                         
	public String from_acc;                              
	public String rec_ins_code;                          
	public String to_acc;

	public NFSTransfer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NFSTransfer(String msg_type, String pan, String pro_code, String amount, String trans_date,
			String trans_time, String conv_rate, String stan, String local_date, String local_time, String capt_date,
			String country_code, String recon_date, String rrn, String act_code, String data, String add_amounts,
			String acq_inst_code, String from_acc, String rec_ins_code, String to_acc) {
		super();
		this.msg_type = msg_type;
		this.pan = pan;
		this.pro_code = pro_code;
		this.amount = amount;
		this.trans_date = trans_date;
		this.trans_time = trans_time;
		this.conv_rate = conv_rate;
		this.stan = stan;
		this.local_date = local_date;
		this.local_time = local_time;
		this.capt_date = capt_date;
		this.country_code = country_code;
		this.recon_date = recon_date;
		this.rrn = rrn;
		this.act_code = act_code;
		this.data = data;
		this.add_amounts = add_amounts;
		this.acq_inst_code = acq_inst_code;
		this.from_acc = from_acc;
		this.rec_ins_code = rec_ins_code;
		this.to_acc = to_acc;
	}

	public String getMsg_type() {
		return msg_type;
	}

	public void setMsg_type(String msg_type) {
		this.msg_type = msg_type;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getPro_code() {
		return pro_code;
	}

	public void setPro_code(String pro_code) {
		this.pro_code = pro_code;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getTrans_date() {
		return trans_date;
	}

	public void setTrans_date(String trans_date) {
		this.trans_date = trans_date;
	}

	public String getTrans_time() {
		return trans_time;
	}

	public void setTrans_time(String trans_time) {
		this.trans_time = trans_time;
	}

	public String getConv_rate() {
		return conv_rate;
	}

	public void setConv_rate(String conv_rate) {
		this.conv_rate = conv_rate;
	}

	public String getStan() {
		return stan;
	}

	public void setStan(String stan) {
		this.stan = stan;
	}

	public String getLocal_date() {
		return local_date;
	}

	public void setLocal_date(String local_date) {
		this.local_date = local_date;
	}

	public String getLocal_time() {
		return local_time;
	}

	public void setLocal_time(String local_time) {
		this.local_time = local_time;
	}

	public String getCapt_date() {
		return capt_date;
	}

	public void setCapt_date(String capt_date) {
		this.capt_date = capt_date;
	}

	public String getCountry_code() {
		return country_code;
	}

	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}

	public String getRecon_date() {
		return recon_date;
	}

	public void setRecon_date(String recon_date) {
		this.recon_date = recon_date;
	}

	public String getRrn() {
		return rrn;
	}

	public void setRrn(String rrn) {
		this.rrn = rrn;
	}

	public String getAct_code() {
		return act_code;
	}

	public void setAct_code(String act_code) {
		this.act_code = act_code;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getAdd_amounts() {
		return add_amounts;
	}

	public void setAdd_amounts(String add_amounts) {
		this.add_amounts = add_amounts;
	}

	public String getAcq_inst_code() {
		return acq_inst_code;
	}

	public void setAcq_inst_code(String acq_inst_code) {
		this.acq_inst_code = acq_inst_code;
	}

	public String getFrom_acc() {
		return from_acc;
	}

	public void setFrom_acc(String from_acc) {
		this.from_acc = from_acc;
	}

	public String getRec_ins_code() {
		return rec_ins_code;
	}

	public void setRec_ins_code(String rec_ins_code) {
		this.rec_ins_code = rec_ins_code;
	}

	public String getTo_acc() {
		return to_acc;
	}

	public void setTo_acc(String to_acc) {
		this.to_acc = to_acc;
	}

	@Override
	public String toString() {
		return "NFSTransfer [msg_type=" + msg_type + ", pan=" + pan + ", pro_code=" + pro_code + ", amount=" + amount
				+ ", trans_date=" + trans_date + ", trans_time=" + trans_time + ", conv_rate=" + conv_rate + ", stan="
				+ stan + ", local_date=" + local_date + ", local_time=" + local_time + ", capt_date=" + capt_date
				+ ", country_code=" + country_code + ", recon_date=" + recon_date + ", rrn=" + rrn + ", act_code="
				+ act_code + ", data=" + data + ", add_amounts=" + add_amounts + ", acq_inst_code=" + acq_inst_code
				+ ", from_acc=" + from_acc + ", rec_ins_code=" + rec_ins_code + ", to_acc=" + to_acc + "]";
	}    
	
	 
	
}
