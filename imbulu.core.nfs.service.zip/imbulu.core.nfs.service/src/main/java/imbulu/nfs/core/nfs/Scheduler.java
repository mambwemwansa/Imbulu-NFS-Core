package imbulu.nfs.core.nfs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import imbulu.nfs.core.configs.ISOSetupConfig;
import imbulu.nfs.core.services.CutOffService;
import imbulu.nfs.core.services.PingService;

@EnableScheduling
@Service
public class Scheduler {
  private static final Logger log = LoggerFactory.getLogger(imbulu.nfs.core.nfs.Scheduler.class);
  
  @Autowired
  private PingService pingService;
  private CutOffService cuttoffservice;
  
  @Scheduled(fixedDelayString = "${nfs.service.pinginterval}")
  public void initiatePingRequests() {
    log.debug("****PING REQUEST****");
    if (ISOSetupConfig.getSocketConnection().isSignedOn()) {
      ISOSetupConfig.getSocketConnection().sendRequest(this.pingService.initiate());
      log.debug("****PING REQUEST COMPLETED****");
    } else {
      log.error("****SOCKET CONNECTION IS CURRENTLY NOT SIGNED ON*****");
    } 
  }
  

}
