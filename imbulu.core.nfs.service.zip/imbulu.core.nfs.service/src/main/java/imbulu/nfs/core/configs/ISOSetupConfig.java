package imbulu.nfs.core.configs;


import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import imbulu.nfs.core.nfs.Config;
import imbulu.nfs.core.services.PingService;
import imbulu.nfs.core.services.SocketConnection;
import imbulu.nfs.core.services.Utils;

@Configuration
public class ISOSetupConfig {
  @Autowired
  private Utils utils;
  
  private static SocketConnection socketConnection1;
  
  @Bean
  public SocketConnection getSocketConnection(Config config, PingService pingService) throws IOException {
    SocketConnection socketConnection = new SocketConnection((String)config.getNfsnetwork().get("ip"), Integer.parseInt((String)config.getNfsnetwork().get("port")), config, pingService, this.utils);
    setSocketConnection(socketConnection);
    return socketConnection;
  }
  
  public static SocketConnection getSocketConnection() {
    return socketConnection1;
  }
  
  private static void setSocketConnection(SocketConnection socketConnection) {
    socketConnection1 = socketConnection;
  }
}
