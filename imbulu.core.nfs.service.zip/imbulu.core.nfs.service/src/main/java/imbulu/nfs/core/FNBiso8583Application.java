package imbulu.nfs.core;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.scheduling.annotation.EnableScheduling;

import de.codecentric.boot.admin.server.config.EnableAdminServer;

@EnableScheduling
@EnableAdminServer
@RefreshScope
@SpringBootApplication
public class FNBiso8583Application {
	
    public static void main(String[] args) throws Exception {
        SpringApplication.run(FNBiso8583Application.class, args);
    }
}
