package imbulu.nfs.core.pojos;

public class ResponseData {
	
	ResponseStatus status;

	public ResponseData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResponseData(ResponseStatus status) {
		super();
		this.status = status;
	}

	public ResponseStatus getStatus() {
		return status;
	}

	public void setStatus(ResponseStatus status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ResponseData [status=" + status + "]";
	}
	

}
