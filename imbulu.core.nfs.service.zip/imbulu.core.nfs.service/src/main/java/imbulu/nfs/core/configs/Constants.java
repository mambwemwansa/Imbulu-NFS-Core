package imbulu.nfs.core.configs;


public class Constants {
  public static final String SERVICE_ID = "serviceID";
  
  public static final String CURRENCY_CODE = "currencyCode";
  
  public static final String AUTH_STATUS_CODE = "authStatusCode";
  
  public static final String AUTH_STATUS = "authStatus";
  
  public static final String RESULTS = "results";
  
  public static final String STATUS_CODE = "statusCode";
  
  public static final String STATUS_DESCRIPTION = "statusDescription";
  
  public static final String TXN_TYPE = "txntype";
  
  public static final String PAYER_TRANSACTION_ID = "payerTransactionID";
  
  public static final String FIELD_39 = "field39";
  
  public static final String MTI_ECHO_REQUEST = "1804";
  
  public static final String MTI_ECHO_RESPONSE = "1814";
  
  public static final String MTI_FINANCIAL_REQUEST = "1200";
  
  public static final String MTI_FINANCIAL_RESPONSE = "1210";
  
  public static final String MTI_FINANCIAL_REVERSAL = "1420";
  
  public static final String MTI_FINANCIAL_REVERSAL_ADVICE = "1421";
  
  public static final String MTI_FINANCIAL_REVERSAL_RESPONSE = "1430";
  
  public static final String ECHO_MESSAGE_FUNCTION = "0831";
  
  public static final String SIGN_ON_MESSAGE_FUNCTION = "0801";
  
  public static final String RESPONSE_RECIEVED_LATE = "1421";
}
