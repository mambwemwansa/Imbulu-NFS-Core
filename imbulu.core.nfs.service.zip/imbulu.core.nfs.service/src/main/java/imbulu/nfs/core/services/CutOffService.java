package imbulu.nfs.core.services;

import java.util.Date;
import java.util.TimeZone;

import org.jpos.iso.ISODate;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import imbulu.nfs.core.nfs.Config;

@Service
public class CutOffService {
	private static final Logger logg = LoggerFactory.getLogger(imbulu.nfs.core.services.CutOffService.class);

	@Autowired
	private Config config;

	@Value("${zm.co.fnb.nfs.isolog}")
	private boolean isolog;

	@Autowired
	private Utils utils;

	public byte[] initiate() {
		byte[] data = null;
		try {
			Date d = new Date();
			ISOMsg request = new ISOMsg();
			request.setMTI("1804");
			request.set(7, ISODate.getDateTime(d, TimeZone.getTimeZone("UTC")));
			request.set(11, ISODate.getTime(d, TimeZone.getTimeZone("CAT")));
			request.set(24, "0821");
			request.set(28, ISODate.getANSIDate(d, TimeZone.getTimeZone("CAT")));
			request.set(93, this.config.getField93());
			request.set(94, this.config.getInstitutionid());
			request.setPackager((ISOPackager) this.utils.getIsopackager());
			data = request.pack();

			request.setDirection(2);
			logg.info(this.utils.logISOMsg(request));
			if (isolog) {

				request.dump(System.out, "");
			}
		} catch (ISOException e) {
			logg.error("We have the following exceptions {}", e.getLocalizedMessage());
		}
		return data;
	}

}
