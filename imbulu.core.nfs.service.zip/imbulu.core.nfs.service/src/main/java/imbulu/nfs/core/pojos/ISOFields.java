package imbulu.nfs.core.pojos;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "incoming")
public class ISOFields {
	
	String mti;
	String f1;
	String f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
	String f11;
	String f12;
	String f13;
	String f14;
	String f15;
	String f16;
	String f17;
	String f18;
	String f19;
	String f20;
	String f21;
	String f22;
	String f23;
	String f24;
	String f25;
	String f26;
	String f27;
	String f28;
	String f29;
	String f30;
	String f31;
	String f32;
	String f33;
	String f34;
	String f35;
	String f36;
	@Id
	String f37;
	String f38;
	String f39;
	String f40;
	String f41;
	String f42;
	String f43;
	String f44;
	String f45;
	String f46;
	String f47;
	String f48;
	String f49;
	String f50;
	String f51;
	String f52;
	String f53;
	String f54;
	String f55;
	String f56;
	String f57;
	String f58;
	String f59;
	String f60;
	String f61;
	String f62;
	String f63;
	String f64;
	String f65;
	String f66;
	String f67;
	String f68;
	String f69;
	String f70;
	String f71;
	String f72;
	String f73;
	String f74;
	String f75;
	String f76;
	String f77;
	String f78;
	String f79;
	String f80;
	String f81;
	String f82;
	String f83;
	String f84;
	String f85;
	String f86;
	String f87;
	String f88;
	String f89;
	String f90;
	String f91;
	String f92;
	String f93;
	String f94;
	String f95;
	String f96;
	String f97;
	String f98;
	String f99;
	String f100;
	String f101;
	String f102;
	String f103;
	String f104;
	String f105;
	String f106;
	String f107;
	String f108;
	String f109;
	String f110;
	String f111;
	String f112;
	String f113;
	String f114;
	String f115;
	String f116;
	String f117;
	String f118;
	String f119;
	String f120;
	String f121;
	String f122;
	String f123;
	String f124;
	String f125;
	String f126;
	String f127;
	String f128;

	public ISOFields() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ISOFields(String mti, String f1, String f2, String f3, String f4, String f5, String f6, String f7, String f8, String f9,
			String f10, String f11, String f12, String f13, String f14, String f15, String f16, String f17, String f18,
			String f19, String f20, String f21, String f22, String f23, String f24, String f25, String f26, String f27,
			String f28, String f29, String f30, String f31, String f32, String f33, String f34, String f35, String f36,
			String f37, String f38, String f39, String f40, String f41, String f42, String f43, String f44, String f45,
			String f46, String f47, String f48, String f49, String f50, String f51, String f52, String f53, String f54,
			String f55, String f56, String f57, String f58, String f59, String f60, String f61, String f62, String f63,
			String f64, String f65, String f66, String f67, String f68, String f69, String f70, String f71, String f72,
			String f73, String f74, String f75, String f76, String f77, String f78, String f79, String f80, String f81,
			String f82, String f83, String f84, String f85, String f86, String f87, String f88, String f89, String f90,
			String f91, String f92, String f93, String f94, String f95, String f96, String f97, String f98, String f99,
			String f100, String f101, String f102, String f103, String f104, String f105, String f106, String f107,
			String f108, String f109, String f110, String f111, String f112, String f113, String f114, String f115,
			String f116, String f117, String f118, String f119, String f120, String f121, String f122, String f123,
			String f124, String f125, String f126, String f127, String f128) {
		super();
		this.mti = mti;
		this.f1 = f1;
		this.f2 = f2;
		this.f3 = f3;
		this.f4 = f4;
		this.f5 = f5;
		this.f6 = f6;
		this.f7 = f7;
		this.f8 = f8;
		this.f9 = f9;
		this.f10 = f10;
		this.f11 = f11;
		this.f12 = f12;
		this.f13 = f13;
		this.f14 = f14;
		this.f15 = f15;
		this.f16 = f16;
		this.f17 = f17;
		this.f18 = f18;
		this.f19 = f19;
		this.f20 = f20;
		this.f21 = f21;
		this.f22 = f22;
		this.f23 = f23;
		this.f24 = f24;
		this.f25 = f25;
		this.f26 = f26;
		this.f27 = f27;
		this.f28 = f28;
		this.f29 = f29;
		this.f30 = f30;
		this.f31 = f31;
		this.f32 = f32;
		this.f33 = f33;
		this.f34 = f34;
		this.f35 = f35;
		this.f36 = f36;
		this.f37 = f37;
		this.f38 = f38;
		this.f39 = f39;
		this.f40 = f40;
		this.f41 = f41;
		this.f42 = f42;
		this.f43 = f43;
		this.f44 = f44;
		this.f45 = f45;
		this.f46 = f46;
		this.f47 = f47;
		this.f48 = f48;
		this.f49 = f49;
		this.f50 = f50;
		this.f51 = f51;
		this.f52 = f52;
		this.f53 = f53;
		this.f54 = f54;
		this.f55 = f55;
		this.f56 = f56;
		this.f57 = f57;
		this.f58 = f58;
		this.f59 = f59;
		this.f60 = f60;
		this.f61 = f61;
		this.f62 = f62;
		this.f63 = f63;
		this.f64 = f64;
		this.f65 = f65;
		this.f66 = f66;
		this.f67 = f67;
		this.f68 = f68;
		this.f69 = f69;
		this.f70 = f70;
		this.f71 = f71;
		this.f72 = f72;
		this.f73 = f73;
		this.f74 = f74;
		this.f75 = f75;
		this.f76 = f76;
		this.f77 = f77;
		this.f78 = f78;
		this.f79 = f79;
		this.f80 = f80;
		this.f81 = f81;
		this.f82 = f82;
		this.f83 = f83;
		this.f84 = f84;
		this.f85 = f85;
		this.f86 = f86;
		this.f87 = f87;
		this.f88 = f88;
		this.f89 = f89;
		this.f90 = f90;
		this.f91 = f91;
		this.f92 = f92;
		this.f93 = f93;
		this.f94 = f94;
		this.f95 = f95;
		this.f96 = f96;
		this.f97 = f97;
		this.f98 = f98;
		this.f99 = f99;
		this.f100 = f100;
		this.f101 = f101;
		this.f102 = f102;
		this.f103 = f103;
		this.f104 = f104;
		this.f105 = f105;
		this.f106 = f106;
		this.f107 = f107;
		this.f108 = f108;
		this.f109 = f109;
		this.f110 = f110;
		this.f111 = f111;
		this.f112 = f112;
		this.f113 = f113;
		this.f114 = f114;
		this.f115 = f115;
		this.f116 = f116;
		this.f117 = f117;
		this.f118 = f118;
		this.f119 = f119;
		this.f120 = f120;
		this.f121 = f121;
		this.f122 = f122;
		this.f123 = f123;
		this.f124 = f124;
		this.f125 = f125;
		this.f126 = f126;
		this.f127 = f127;
		this.f128 = f128;
	}

	public String getMti() {
		return mti;
	}

	public void setMti(String mti) {
		this.mti = mti;
	}

	public String getF1() {
		return f1;
	}

	public void setF1(String f1) {
		this.f1 = f1;
	}

	public String getF2() {
		return f2;
	}

	public void setF2(String f2) {
		this.f2 = f2;
	}

	public String getF3() {
		return f3;
	}

	public void setF3(String f3) {
		this.f3 = f3;
	}

	public String getF4() {
		return f4;
	}

	public void setF4(String f4) {
		this.f4 = f4;
	}

	public String getF5() {
		return f5;
	}

	public void setF5(String f5) {
		this.f5 = f5;
	}

	public String getF6() {
		return f6;
	}

	public void setF6(String f6) {
		this.f6 = f6;
	}

	public String getF7() {
		return f7;
	}

	public void setF7(String f7) {
		this.f7 = f7;
	}

	public String getF8() {
		return f8;
	}

	public void setF8(String f8) {
		this.f8 = f8;
	}

	public String getF9() {
		return f9;
	}

	public void setF9(String f9) {
		this.f9 = f9;
	}

	public String getF10() {
		return f10;
	}

	public void setF10(String f10) {
		this.f10 = f10;
	}

	public String getF11() {
		return f11;
	}

	public void setF11(String f11) {
		this.f11 = f11;
	}

	public String getF12() {
		return f12;
	}

	public void setF12(String f12) {
		this.f12 = f12;
	}

	public String getF13() {
		return f13;
	}

	public void setF13(String f13) {
		this.f13 = f13;
	}

	public String getF14() {
		return f14;
	}

	public void setF14(String f14) {
		this.f14 = f14;
	}

	public String getF15() {
		return f15;
	}

	public void setF15(String f15) {
		this.f15 = f15;
	}

	public String getF16() {
		return f16;
	}

	public void setF16(String f16) {
		this.f16 = f16;
	}

	public String getF17() {
		return f17;
	}

	public void setF17(String f17) {
		this.f17 = f17;
	}

	public String getF18() {
		return f18;
	}

	public void setF18(String f18) {
		this.f18 = f18;
	}

	public String getF19() {
		return f19;
	}

	public void setF19(String f19) {
		this.f19 = f19;
	}

	public String getF20() {
		return f20;
	}

	public void setF20(String f20) {
		this.f20 = f20;
	}

	public String getF21() {
		return f21;
	}

	public void setF21(String f21) {
		this.f21 = f21;
	}

	public String getF22() {
		return f22;
	}

	public void setF22(String f22) {
		this.f22 = f22;
	}

	public String getF23() {
		return f23;
	}

	public void setF23(String f23) {
		this.f23 = f23;
	}

	public String getF24() {
		return f24;
	}

	public void setF24(String f24) {
		this.f24 = f24;
	}

	public String getF25() {
		return f25;
	}

	public void setF25(String f25) {
		this.f25 = f25;
	}

	public String getF26() {
		return f26;
	}

	public void setF26(String f26) {
		this.f26 = f26;
	}

	public String getF27() {
		return f27;
	}

	public void setF27(String f27) {
		this.f27 = f27;
	}

	public String getF28() {
		return f28;
	}

	public void setF28(String f28) {
		this.f28 = f28;
	}

	public String getF29() {
		return f29;
	}

	public void setF29(String f29) {
		this.f29 = f29;
	}

	public String getF30() {
		return f30;
	}

	public void setF30(String f30) {
		this.f30 = f30;
	}

	public String getF31() {
		return f31;
	}

	public void setF31(String f31) {
		this.f31 = f31;
	}

	public String getF32() {
		return f32;
	}

	public void setF32(String f32) {
		this.f32 = f32;
	}

	public String getF33() {
		return f33;
	}

	public void setF33(String f33) {
		this.f33 = f33;
	}

	public String getF34() {
		return f34;
	}

	public void setF34(String f34) {
		this.f34 = f34;
	}

	public String getF35() {
		return f35;
	}

	public void setF35(String f35) {
		this.f35 = f35;
	}

	public String getF36() {
		return f36;
	}

	public void setF36(String f36) {
		this.f36 = f36;
	}

	public String getF37() {
		return f37;
	}

	public void setF37(String f37) {
		this.f37 = f37;
	}

	public String getF38() {
		return f38;
	}

	public void setF38(String f38) {
		this.f38 = f38;
	}

	public String getF39() {
		return f39;
	}

	public void setF39(String f39) {
		this.f39 = f39;
	}

	public String getF40() {
		return f40;
	}

	public void setF40(String f40) {
		this.f40 = f40;
	}

	public String getF41() {
		return f41;
	}

	public void setF41(String f41) {
		this.f41 = f41;
	}

	public String getF42() {
		return f42;
	}

	public void setF42(String f42) {
		this.f42 = f42;
	}

	public String getF43() {
		return f43;
	}

	public void setF43(String f43) {
		this.f43 = f43;
	}

	public String getF44() {
		return f44;
	}

	public void setF44(String f44) {
		this.f44 = f44;
	}

	public String getF45() {
		return f45;
	}

	public void setF45(String f45) {
		this.f45 = f45;
	}

	public String getF46() {
		return f46;
	}

	public void setF46(String f46) {
		this.f46 = f46;
	}

	public String getF47() {
		return f47;
	}

	public void setF47(String f47) {
		this.f47 = f47;
	}

	public String getF48() {
		return f48;
	}

	public void setF48(String f48) {
		this.f48 = f48;
	}

	public String getF49() {
		return f49;
	}

	public void setF49(String f49) {
		this.f49 = f49;
	}

	public String getF50() {
		return f50;
	}

	public void setF50(String f50) {
		this.f50 = f50;
	}

	public String getF51() {
		return f51;
	}

	public void setF51(String f51) {
		this.f51 = f51;
	}

	public String getF52() {
		return f52;
	}

	public void setF52(String f52) {
		this.f52 = f52;
	}

	public String getF53() {
		return f53;
	}

	public void setF53(String f53) {
		this.f53 = f53;
	}

	public String getF54() {
		return f54;
	}

	public void setF54(String f54) {
		this.f54 = f54;
	}

	public String getF55() {
		return f55;
	}

	public void setF55(String f55) {
		this.f55 = f55;
	}

	public String getF56() {
		return f56;
	}

	public void setF56(String f56) {
		this.f56 = f56;
	}

	public String getF57() {
		return f57;
	}

	public void setF57(String f57) {
		this.f57 = f57;
	}

	public String getF58() {
		return f58;
	}

	public void setF58(String f58) {
		this.f58 = f58;
	}

	public String getF59() {
		return f59;
	}

	public void setF59(String f59) {
		this.f59 = f59;
	}

	public String getF60() {
		return f60;
	}

	public void setF60(String f60) {
		this.f60 = f60;
	}

	public String getF61() {
		return f61;
	}

	public void setF61(String f61) {
		this.f61 = f61;
	}

	public String getF62() {
		return f62;
	}

	public void setF62(String f62) {
		this.f62 = f62;
	}

	public String getF63() {
		return f63;
	}

	public void setF63(String f63) {
		this.f63 = f63;
	}

	public String getF64() {
		return f64;
	}

	public void setF64(String f64) {
		this.f64 = f64;
	}

	public String getF65() {
		return f65;
	}

	public void setF65(String f65) {
		this.f65 = f65;
	}

	public String getF66() {
		return f66;
	}

	public void setF66(String f66) {
		this.f66 = f66;
	}

	public String getF67() {
		return f67;
	}

	public void setF67(String f67) {
		this.f67 = f67;
	}

	public String getF68() {
		return f68;
	}

	public void setF68(String f68) {
		this.f68 = f68;
	}

	public String getF69() {
		return f69;
	}

	public void setF69(String f69) {
		this.f69 = f69;
	}

	public String getF70() {
		return f70;
	}

	public void setF70(String f70) {
		this.f70 = f70;
	}

	public String getF71() {
		return f71;
	}

	public void setF71(String f71) {
		this.f71 = f71;
	}

	public String getF72() {
		return f72;
	}

	public void setF72(String f72) {
		this.f72 = f72;
	}

	public String getF73() {
		return f73;
	}

	public void setF73(String f73) {
		this.f73 = f73;
	}

	public String getF74() {
		return f74;
	}

	public void setF74(String f74) {
		this.f74 = f74;
	}

	public String getF75() {
		return f75;
	}

	public void setF75(String f75) {
		this.f75 = f75;
	}

	public String getF76() {
		return f76;
	}

	public void setF76(String f76) {
		this.f76 = f76;
	}

	public String getF77() {
		return f77;
	}

	public void setF77(String f77) {
		this.f77 = f77;
	}

	public String getF78() {
		return f78;
	}

	public void setF78(String f78) {
		this.f78 = f78;
	}

	public String getF79() {
		return f79;
	}

	public void setF79(String f79) {
		this.f79 = f79;
	}

	public String getF80() {
		return f80;
	}

	public void setF80(String f80) {
		this.f80 = f80;
	}

	public String getF81() {
		return f81;
	}

	public void setF81(String f81) {
		this.f81 = f81;
	}

	public String getF82() {
		return f82;
	}

	public void setF82(String f82) {
		this.f82 = f82;
	}

	public String getF83() {
		return f83;
	}

	public void setF83(String f83) {
		this.f83 = f83;
	}

	public String getF84() {
		return f84;
	}

	public void setF84(String f84) {
		this.f84 = f84;
	}

	public String getF85() {
		return f85;
	}

	public void setF85(String f85) {
		this.f85 = f85;
	}

	public String getF86() {
		return f86;
	}

	public void setF86(String f86) {
		this.f86 = f86;
	}

	public String getF87() {
		return f87;
	}

	public void setF87(String f87) {
		this.f87 = f87;
	}

	public String getF88() {
		return f88;
	}

	public void setF88(String f88) {
		this.f88 = f88;
	}

	public String getF89() {
		return f89;
	}

	public void setF89(String f89) {
		this.f89 = f89;
	}

	public String getF90() {
		return f90;
	}

	public void setF90(String f90) {
		this.f90 = f90;
	}

	public String getF91() {
		return f91;
	}

	public void setF91(String f91) {
		this.f91 = f91;
	}

	public String getF92() {
		return f92;
	}

	public void setF92(String f92) {
		this.f92 = f92;
	}

	public String getF93() {
		return f93;
	}

	public void setF93(String f93) {
		this.f93 = f93;
	}

	public String getF94() {
		return f94;
	}

	public void setF94(String f94) {
		this.f94 = f94;
	}

	public String getF95() {
		return f95;
	}

	public void setF95(String f95) {
		this.f95 = f95;
	}

	public String getF96() {
		return f96;
	}

	public void setF96(String f96) {
		this.f96 = f96;
	}

	public String getF97() {
		return f97;
	}

	public void setF97(String f97) {
		this.f97 = f97;
	}

	public String getF98() {
		return f98;
	}

	public void setF98(String f98) {
		this.f98 = f98;
	}

	public String getF99() {
		return f99;
	}

	public void setF99(String f99) {
		this.f99 = f99;
	}

	public String getF100() {
		return f100;
	}

	public void setF100(String f100) {
		this.f100 = f100;
	}

	public String getF101() {
		return f101;
	}

	public void setF101(String f101) {
		this.f101 = f101;
	}

	public String getF102() {
		return f102;
	}

	public void setF102(String f102) {
		this.f102 = f102;
	}

	public String getF103() {
		return f103;
	}

	public void setF103(String f103) {
		this.f103 = f103;
	}

	public String getF104() {
		return f104;
	}

	public void setF104(String f104) {
		this.f104 = f104;
	}

	public String getF105() {
		return f105;
	}

	public void setF105(String f105) {
		this.f105 = f105;
	}

	public String getF106() {
		return f106;
	}

	public void setF106(String f106) {
		this.f106 = f106;
	}

	public String getF107() {
		return f107;
	}

	public void setF107(String f107) {
		this.f107 = f107;
	}

	public String getF108() {
		return f108;
	}

	public void setF108(String f108) {
		this.f108 = f108;
	}

	public String getF109() {
		return f109;
	}

	public void setF109(String f109) {
		this.f109 = f109;
	}

	public String getF110() {
		return f110;
	}

	public void setF110(String f110) {
		this.f110 = f110;
	}

	public String getF111() {
		return f111;
	}

	public void setF111(String f111) {
		this.f111 = f111;
	}

	public String getF112() {
		return f112;
	}

	public void setF112(String f112) {
		this.f112 = f112;
	}

	public String getF113() {
		return f113;
	}

	public void setF113(String f113) {
		this.f113 = f113;
	}

	public String getF114() {
		return f114;
	}

	public void setF114(String f114) {
		this.f114 = f114;
	}

	public String getF115() {
		return f115;
	}

	public void setF115(String f115) {
		this.f115 = f115;
	}

	public String getF116() {
		return f116;
	}

	public void setF116(String f116) {
		this.f116 = f116;
	}

	public String getF117() {
		return f117;
	}

	public void setF117(String f117) {
		this.f117 = f117;
	}

	public String getF118() {
		return f118;
	}

	public void setF118(String f118) {
		this.f118 = f118;
	}

	public String getF119() {
		return f119;
	}

	public void setF119(String f119) {
		this.f119 = f119;
	}

	public String getF120() {
		return f120;
	}

	public void setF120(String f120) {
		this.f120 = f120;
	}

	public String getF121() {
		return f121;
	}

	public void setF121(String f121) {
		this.f121 = f121;
	}

	public String getF122() {
		return f122;
	}

	public void setF122(String f122) {
		this.f122 = f122;
	}

	public String getF123() {
		return f123;
	}

	public void setF123(String f123) {
		this.f123 = f123;
	}

	public String getF124() {
		return f124;
	}

	public void setF124(String f124) {
		this.f124 = f124;
	}

	public String getF125() {
		return f125;
	}

	public void setF125(String f125) {
		this.f125 = f125;
	}

	public String getF126() {
		return f126;
	}

	public void setF126(String f126) {
		this.f126 = f126;
	}

	public String getF127() {
		return f127;
	}

	public void setF127(String f127) {
		this.f127 = f127;
	}

	public String getF128() {
		return f128;
	}

	public void setF128(String f128) {
		this.f128 = f128;
	}

	
	
}
