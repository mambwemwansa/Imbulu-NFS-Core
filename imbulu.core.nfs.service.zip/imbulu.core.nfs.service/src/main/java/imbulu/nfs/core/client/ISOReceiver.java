package imbulu.nfs.core.client;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import org.jpos.core.Configuration;
import org.jpos.iso.BaseChannel;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.jpos.iso.ISORequestListener;
import org.jpos.iso.ISOSource;
import org.jpos.iso.ISOUtil;
import org.jpos.iso.packager.GenericPackager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import imbulu.nfs.core.configs.ISOSetupConfig;
import imbulu.nfs.core.nfs.Config;
import imbulu.nfs.core.services.ISOService;
import imbulu.nfs.core.services.SocketConnection;
import imbulu.nfs.core.services.Utils;

@Service
public class ISOReceiver {
	private static final Logger logger = LoggerFactory.getLogger(imbulu.nfs.core.client.ISOReceiver.class);

	@Autowired
	private Utils utils;

	@Autowired
	private ClientConfigurations clientconfigurations;

	@Autowired
	private Packager clientpackager;

	@Autowired
	private Config config;

	@Value("${zm.co.fnb.nfs.inwards.v1}")
	private String inwardsv1;

	@Value("${zm.co.fnb.nfs.outwards.v1}")
	private String outwardsv1;

	@Value("${zm.co.fnb.nfs.inwards.v1.URL}")
	private String inwardsv1_URL;

	@Value("${zm.co.fnb.nfs.outwards.v1.URL}")
	private String outwardsv1_URL;

	@Value("${zm.co.fnb.nfs.backpass.v1.URL}")
	private String backpass_URL;

	@Autowired
	ISOService iSOService;
	@Value("${zm.co.fnb.nfs.isolog}")
	private boolean isolog;

	public void receive(byte[] data) {
		try {
			logger.debug("We are now processing in the receive ");
			ISOMsg iSOMsg = new ISOMsg();
			iSOMsg.setDirection(1);
			if (data != null) {
				Configuration configuration = this.clientconfigurations.getConfigs();
				GenericPackager genericPackager = this.clientpackager.getpackager(configuration);
				iSOMsg.setPackager((ISOPackager) genericPackager);
				iSOMsg.unpack(data);
				logger.info(this.utils.logISOMsg(iSOMsg));
				if (isolog) {

					iSOMsg.dump(System.out, "");
				}
				processIncomingByMTI(iSOMsg.getMTI(), iSOMsg, genericPackager);
			} else {
				logger.debug("No Message sent from ZECHL");
			}
		} catch (ISOException ex) {
			logger.error("Error: {} Cause: {}", ex.getMessage(), ex.getLocalizedMessage());

		} catch (Exception ex) {
			logger.error("The general following general exception " + ex.getLocalizedMessage());
		}
		logger.debug("Exiting reciever");
	}

	private void processIncomingByMTI(String mti, ISOMsg iSOMsg, GenericPackager genericPackager) throws ISOException {
		String type;
		SocketConnection socketConnection;
		logger.debug("MTI Recieved {} processIncomingByMTI", iSOMsg.getMTI());
		switch (mti) {
		case "1804":
			String type24 = "";
			if (iSOMsg.getString(24).equals(this.config.getNfsTransactionStatuses().get("signOnMessagefunctionCode"))) {
				type = "SIGNON";
			} else if (iSOMsg.getString(24)
					.equals(this.config.getNfsTransactionStatuses().get("echoMessagfunctionCode"))) {
				type = "ECHO";
			} else {
				type = "CUTOFF";
			}
			logger.debug("We have recieved the following MTI {} and pushing the following type {}", iSOMsg.getMTI(),
					type24);
			iSOMsg.setResponseMTI();
			iSOMsg.set(39, (String) this.config.getNfsTransactionStatuses().get("echoSuccessFunctionCode"));
			iSOMsg.setDirection(1);
			iSOMsg.setPackager((ISOPackager) genericPackager);
			socketConnection = ISOSetupConfig.getSocketConnection();
			socketConnection.sendRequest(iSOMsg.pack());
			logger.debug(type24.toUpperCase() + " Network MSG response sent: " + ISOUtil.byte2hex(iSOMsg.pack()));
			return;
		case "1814":
			logger.debug("Network MSG response received:: " + iSOMsg.getMTI());
			if (iSOMsg.hasField(39))
				if (iSOMsg.getString("39")
						.equals(this.config.getNfsTransactionStatuses().get("echoSuccessFunctionCode"))) {
					switch (iSOMsg.getString(24)) {
					case "0801":
						logger.debug("Status {}-> {}", "0801", iSOMsg.getString("39"));
						iSOMsg.setDirection(2);
						return;
					case "0831":
						logger.debug("Status {}-> {}", "0831", iSOMsg.getString("39"));
						return;
					}
					iSOMsg.setPackager((ISOPackager) genericPackager);
					socketConnection = ISOSetupConfig.getSocketConnection();
					socketConnection.sendRequest(iSOMsg.pack());
					logger.debug("Default Status {}", iSOMsg.getString("39"));
				} else if (iSOMsg.getString("24")
						.equals(this.config.getNfsTransactionStatuses().get("echoMessagfunctionCode"))) {
					logger.debug("Status {}", iSOMsg.getString("24"));
				}
			return;
		default:
			String[] outwardsIN = outwardsv1.split(",");
			String[] inwardIN = inwardsv1.split(",");
			String url = null;
			if (Arrays.stream(outwardsIN).anyMatch(iSOMsg.getMTI()::equals)) {
				url = outwardsv1_URL;
			} else if (Arrays.stream(inwardIN).anyMatch(iSOMsg.getMTI()::equals)) {
				url = inwardsv1_URL;
			} else {
				url = backpass_URL;
			}
			logger.debug("We have {}", iSOMsg.getMTI());
			iSOService.sendHTTPIncoming(iSOMsg, url);
			return;
		}
	}

}
