package imbulu.nfs.core.services;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.jpos.iso.ISOUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import imbulu.nfs.core.client.ISOReceiver;
import imbulu.nfs.core.nfs.Config;

public class SocketConnection extends Thread {
	private static final Logger logger = LoggerFactory.getLogger(imbulu.nfs.core.services.SocketConnection.class);

	@Autowired
	private Config config;
	@Autowired
	private ISOReceiver isoReceiver;
	@Autowired
	private Utils utils;
	private Socket socket;
	private BufferedOutputStream output;
	private InputStream input;
	private String host;
	private int port;
	private boolean isSignedOn;
	private PingService pingService;

	public SocketConnection(String host, int port, Config config2, PingService pingServicebean, Utils utils) {
		try {
			logger.info("trying to connect to {} on port {}", host, Integer.valueOf(port));
			this.port = port;
			this.host = host;
			this.socket = new Socket();
			this.socket.connect(new InetSocketAddress(host, port));
			this.socket.setReuseAddress(true);
			this.socket.setKeepAlive(true);
			this.config = config2;
			this.output = new BufferedOutputStream(this.socket.getOutputStream());
			this.input = this.socket.getInputStream();
			this.pingService = pingServicebean;
			this.utils = utils;
			setIsSignedOn(true);
			logger.info("successfully established connection");
		} catch (IOException | NumberFormatException ex2) {
			logger.error("An Exception occurred.... Message : " + ex2.getLocalizedMessage());
		}
	}

	public synchronized void sendRequest(byte[] request) {
		try {
			byte[] data = this.utils.parseRequest(request);
			logger.debug("sending {} Length {}", ISOUtil.byte2hex(data), data.length);
			this.output.write(data);
			this.output.flush();
			logger.debug("send complete");
		} catch (IOException ex) {

			if (ex.getLocalizedMessage().contains("socket write error.")) {
				try {
					this.output.flush();
				} catch (IOException e) {
					e.printStackTrace();
				}
			} else {
				logger.error("Couldn't get I/O for the connection Exception. Exception : " + ex.getLocalizedMessage()
						+ ". Try re connecting");
				connect(this.host, this.port);

			}
		} catch (Exception ex2) {
			logger.error("Unhandled exception occurred\n: " + ExceptionUtils.getStackTrace(ex2) + ".");
		}
	}

	public boolean isSignedOn() {
		return this.isSignedOn;
	}

	private void setIsSignedOn(boolean isSignedOn) {
		this.isSignedOn = isSignedOn;
	}

	private synchronized void connect(String server, int port) {
		try {
			closeConnection();
			logger.info("Creating new socket connection to " + server + " - Port : " + port);
			this.socket = new Socket();
			this.socket.connect(new InetSocketAddress(this.host, port));
			this.socket.setReuseAddress(true);
			this.socket.setKeepAlive(true);
			this.output = new BufferedOutputStream(this.socket.getOutputStream());
			this.input = this.socket.getInputStream();
			logger.info("successfully re-established connectivity");
			setIsSignedOn(true);
			sendRequest(this.pingService.signOn());
			sendRequest(this.pingService.initiate());
		} catch (UnknownHostException e) {
			logger.error("An UnknownHostException occurred. Message : " + e.getLocalizedMessage());
			closeConnection();
		} catch (IOException e2) {
			logger.error("going to sleep");
			if (!this.isSignedOn)
				connect(server, port);
		} catch (Exception exception) {
			logger.error("We have the following exception ", ExceptionUtils.getStackTrace(exception));
		}
	}

	public synchronized void closeConnection() {
		try {
			logger.info("Close Socket Connection....");
			setIsSignedOn(false);
			if (null != this.socket) {
				if (null != this.input) {
					logger.info("Input Stream is not null, about to close it...");
					this.input.close();
				} else {
					logger.info("Input Stream is null...");
				}
				if (null != this.output) {
					logger.info("Output Stream is not null, about to close it...");
					this.output.close();
				} else {
					logger.info("Output Stream is null...");
				}
				logger.debug("Socket Connection is not null, about to close it...");
				this.socket.close();
			} else {
				logger.info("Socket Connection is null...");
			}
			logger.info("About to reinitialize Connection values...");
			this.input = null;
			this.output = null;
			this.socket = null;
		} catch (IOException ex) {
			logger.error("An IO Close Socket Connection occurred.... Message : " + ex.getLocalizedMessage());
		}
	}

	@Override
	public void run() {
		logger.debug("getting in while true");
		try {
			while (true) {
				try {
					byte[] arrOutut = new byte[4096];
					int count = this.input.read(arrOutut, 0, 4096);
					if (count > 0) {
						int controlIndexByte = this.config.getIndexControl();
						byte[] recieved = Arrays.copyOfRange(arrOutut, 0, count);
						logger.debug(" Received ByteArray {}", ISOUtil.hexString(recieved));
						while (recieved.length > 0) {
							try {
								int countArray = recieved.length;
								logger.debug("array length {} ", Integer.valueOf(recieved.length));
								byte[] messageLengthBytes = Arrays.copyOfRange(recieved, 0, 2);
								int messageLength = Integer.parseInt(ISOUtil.byte2hex(messageLengthBytes), 16);
								this.isoReceiver
										.receive(Arrays.copyOfRange(recieved, 23, messageLength + controlIndexByte));
								recieved = Arrays.copyOfRange(recieved, messageLength + messageLengthBytes.length,
										countArray);
							} catch (Exception e) {
								StringBuffer sb = new StringBuffer();
								sb.append("Exception occured : " + e.getMessage() + " \n");
								sb.append("REJECTED Received Parse\n"
										+ ISOUtil.hexdump(ISOUtil.hex2byte(ISOUtil.hexString(recieved))) + "\n");
								logger.info(sb.toString());
								break;
							}
						}
						continue;
					}
					logger.info("no information received");
					sendRequest(this.pingService.initiate());
				} catch (IOException ex2) {
					logger.error("Couldn't get I/O for the connection Exception. Reconnecting...");
					connect(this.host, this.port);
				} catch (NumberFormatException ex) {
					logger.error("Number format Exception Exception : " + ex.getMessage());

				}
			}
		} catch (Exception e) {
			logger.error("Restarting Thread!");
			logger.error("We have the following exception\n " + ExceptionUtils.getStackTrace(e));
			this.start();
			logger.error("Thread Started!");
			return;
		}

	}

	@Override
	public void interrupt() {
		// TODO Auto-generated method stub
		super.interrupt();
		logger.error("The Thread has been interuppted");
	}

}
