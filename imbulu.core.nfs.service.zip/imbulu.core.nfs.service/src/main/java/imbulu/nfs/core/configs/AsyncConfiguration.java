package imbulu.nfs.core.configs;


import java.util.concurrent.Executor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import imbulu.nfs.core.nfs.Config;

@Configuration
@EnableAsync
public class AsyncConfiguration implements AsyncConfigurer {
  @Autowired
  private Config config;
  
  public TaskExecutor getAsyncExecutor() {
    ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    executor.setCorePoolSize(this.config.getCorePoolSize().intValue());
    executor.setMaxPoolSize(this.config.getMaxPoolSize().intValue());
    executor.setThreadNamePrefix("task_executor_thread");
    executor.afterPropertiesSet();
    executor.initialize();
    return (TaskExecutor)executor;
  }
}


