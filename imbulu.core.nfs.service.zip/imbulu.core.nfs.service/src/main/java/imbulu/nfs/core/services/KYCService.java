package imbulu.nfs.core.services;

import java.util.Date;
import java.util.TimeZone;
import org.jpos.iso.ISODate;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import imbulu.nfs.core.nfs.Config;
import imbulu.nfs.core.pojos.NFSTransfer;
import imbulu.nfs.core.services.Utils;

@Service
public class KYCService {
	private static final Logger log = LoggerFactory.getLogger(imbulu.nfs.core.services.KYCService.class);

	@Autowired
	private Config config;

	@Autowired
	private Utils utils;

	public byte[] buildTransfer(NFSTransfer transfer) {
		byte[] data = null;
		try {
			Date d = new Date();
			ISOMsg request = new ISOMsg();
			request.setMTI("1200");
			request.set(2, "0002********8467");
			request.set(3, "310000");
			request.set(4, "000000000000");
			request.set(7, "0117214646");
			request.set(11, "860001");
			request.set(12, "200324");
			request.set(17, "324");
			request.set(19, "894");
			request.set(22, "000010Z00000");
			request.set(24, "200");
			request.set(26, "5271");
			request.set(32, "000211");
			request.set(37, "008408000861");
			request.set(41, "11111111");
			request.set(42, "333333333333333");
			request.set(49, "967");
			request.set(102, "0002021802687028001");
			request.set(103, "0002040974538467");
			request.setPackager((ISOPackager) this.utils.getIsopackager());
			data = request.pack();
		} catch (ISOException e) {
			log.error("We have the following exceptions {}", e.getLocalizedMessage());
		}
		return data;
	}
}
