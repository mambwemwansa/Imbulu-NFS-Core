package imbulu.nfs.core.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import imbulu.nfs.core.pojos.ISOFields;
import imbulu.nfs.core.pojos.Log;
import imbulu.nfs.core.services.KYCService;


@Repository
public interface ISOFieldsRepo extends JpaRepository<ISOFields, String> {
	

}
