package imbulu.nfs.core.controller;

import java.sql.Timestamp;
import java.util.Arrays;

import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import imbulu.nfs.core.configs.ISOSetupConfig;
import imbulu.nfs.core.dao.ISOFieldsRepo;
import imbulu.nfs.core.nfs.Config;
import imbulu.nfs.core.pojos.ISOFields;
import imbulu.nfs.core.pojos.NFSTransfer;
import imbulu.nfs.core.pojos.ResponseData;
import imbulu.nfs.core.pojos.ResponseStatus;
import imbulu.nfs.core.services.ISOService;
import imbulu.nfs.core.services.KYCService;
import imbulu.nfs.core.services.TransferService;
import imbulu.nfs.core.services.Utils;

@RestController
@RequestMapping("/emoney/")
public class Appweb {

	@Autowired
	TransferService transferService;
	@Autowired
	ISOService iSOService;
	@Autowired
	KYCService kycService;
	@Autowired
	private Config config;
	@Autowired
	private Utils utils;
	@Autowired
	ISOFieldsRepo iSOFieldsRepo;
	@Value("${zm.co.fnb.nfs.isolog}")
	private boolean isolog;

	private static final Logger logger = LoggerFactory.getLogger(Appweb.class);

	@PostMapping(value = "tran-status", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String transferRequest(@RequestBody NFSTransfer transfer) {

		logger.debug("REQ --> " + new Gson().toJson(transfer));
		ISOSetupConfig.getSocketConnection().sendRequest(this.transferService.buildTransfer(transfer));
		return new Gson().toJson(transfer);
	}

	@PostMapping(value = "outbound", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<String> createISO(@RequestBody ISOFields request) {

		ISOMsg iso = new ISOMsg();
		try {
			iso = utils.getISOfromPOjo(request);
			logger.debug("REQ => " + new Gson().toJson(request));
			if (iso.hasField(48) & "310000".equals(iso.getValue(3))
					& (iso.getString(32) != config.getInstitutionid())) {
				String[] nameAddress = iso.getString(48).split("~");
				logger.debug("NameAddressString => " + Arrays.toString(nameAddress));
				iso.set(48, utils.wrappNameAddress(nameAddress[0].toString(), nameAddress[1].toString()));
			}

			if (iso.hasField(48) & ("400000".equals(iso.getValue(3)) | "401000".equals(iso.getValue(3)) | "210000".equals(iso.getValue(3)))
					& (iso.getString(32) != config.getInstitutionid())) {
				String[] nameNarration = iso.getString(48).split("~");
				logger.debug("nameNarrationString => " + Arrays.toString(nameNarration));
				iso.set(48, utils.wrappNameNarration(nameNarration[1].toString(), nameNarration[0].toString()));
			}

			if (iso.hasField(48) & "010000".equals(iso.getValue(3))
					& (iso.getString(32) != config.getInstitutionid())) {
				String otp = iso.getString(48);
				iso.set(48, utils.wrappOTP(otp));
			}
			iso.setDirection(2);
			ISOSetupConfig.getSocketConnection().sendRequest(this.iSOService.build(iso));
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("[ERROR] => " + e.getLocalizedMessage());
			ResponseData data = new ResponseData();
			ResponseStatus status = new ResponseStatus("503",iso.getString(37),"ISO Message bad gateway",new Timestamp(System.currentTimeMillis()).toString());
			data.setStatus(status);
			return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(new Gson().toJson(data));

		}
		
		ResponseData data = new ResponseData();
		ResponseStatus status = new ResponseStatus("201",iso.getString(37),"ISO Message has created successfully",new Timestamp(System.currentTimeMillis()).toString());
		data.setStatus(status);
		return ResponseEntity.status(HttpStatus.OK).body(new Gson().toJson(data));
	}

	@PostMapping(value = "inbound", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String receiveISO(@RequestBody String request) {
		try {
			logger.debug("[INBOUND INCOMING] --> " + new Gson().toJson(request));
			ISOFields iso = new ObjectMapper().readValue(request, ISOFields.class);
			iSOFieldsRepo.save(iso);

		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new Gson().toJson("INCOMING END");
	}

}
