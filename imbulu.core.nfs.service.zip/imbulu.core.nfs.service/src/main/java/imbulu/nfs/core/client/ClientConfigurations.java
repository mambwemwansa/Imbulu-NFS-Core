package imbulu.nfs.core.client;

import org.jpos.core.Configuration;
import org.jpos.core.SimpleConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import imbulu.nfs.core.nfs.Config;

@Service
public class ClientConfigurations {
  @Autowired
  private Config config;
  
  public Configuration getConfigs() {
    SimpleConfiguration simpleConfiguration = new SimpleConfiguration();
    simpleConfiguration.put("packager-config", this.config.getPackagerconfig());
    simpleConfiguration.put("packager-logger", this.config.getCustomConfig().get("packagerLogger"));
    simpleConfiguration.put("packager-realm", this.config.getCustomConfig().get("packagerRealm"));
    simpleConfiguration.put("host", this.config.getIp());
    simpleConfiguration.put("port", this.config.getPort());
    simpleConfiguration.put("timeout", String.valueOf(Integer.parseInt(this.config.getTimeout()) * 1000));
    simpleConfiguration.put("alternate-host", this.config.getCustomConfig().get("alternateIP"));
    simpleConfiguration.put("alternate-port", this.config.getCustomConfig().get("alternatePort"));
    simpleConfiguration.put("keep-alive", Boolean.valueOf(this.config.isKeepalive()));
    simpleConfiguration.put("expect-keep-alive", Boolean.valueOf(this.config.isExpectkeepalive()));
    simpleConfiguration.put("loggername", this.config.getLoggername());
    simpleConfiguration.put("echoInterval", this.config.getEchointerval());
    simpleConfiguration.put("max-size", Integer.valueOf(this.config.getThreadsize()));
    simpleConfiguration.put("signonwait", String.valueOf(Integer.parseInt(this.config.getSignonwait()) * 1000));
    return (Configuration)simpleConfiguration;
  }
}
