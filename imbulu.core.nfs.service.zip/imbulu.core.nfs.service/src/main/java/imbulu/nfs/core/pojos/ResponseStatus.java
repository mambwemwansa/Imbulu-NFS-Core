package imbulu.nfs.core.pojos;

public class ResponseStatus {
	String code;
	String rrn;
	String description;
	String timestamp;
	public ResponseStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ResponseStatus(String code, String rrn, String description, String timestamp) {
		super();
		this.code = code;
		this.rrn = rrn;
		this.description = description;
		this.timestamp = timestamp;
	}
	String getCode() {
		return code;
	}
	void setCode(String code) {
		this.code = code;
	}
	String getRrn() {
		return rrn;
	}
	void setRrn(String rrn) {
		this.rrn = rrn;
	}
	String getDescription() {
		return description;
	}
	void setDescription(String description) {
		this.description = description;
	}
	String getTimestamp() {
		return timestamp;
	}
	void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	@Override
	public String toString() {
		return "ResponseStatus [code=" + code + ", rrn=" + rrn + ", description=" + description + ", timestamp="
				+ timestamp + "]";
	}

	
	  
}
