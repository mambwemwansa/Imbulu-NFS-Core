package imbulu.nfs.core.configs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import imbulu.nfs.core.configs.ISOSetupConfig;
import imbulu.nfs.core.services.PingService;

@Component
public class StartUp implements ApplicationListener<ContextRefreshedEvent> {
  private static final Logger log = LoggerFactory.getLogger(imbulu.nfs.core.configs.StartUp.class);
  
  @Autowired
  public PingService pingService;
  
  public void onApplicationEvent(ContextRefreshedEvent event) {
    log.info("we are starting the reading bit");
    ISOSetupConfig.getSocketConnection().start();
    log.info("sending signOn in a bit");
    ISOSetupConfig.getSocketConnection().sendRequest(this.pingService.signOn());
  }
}
