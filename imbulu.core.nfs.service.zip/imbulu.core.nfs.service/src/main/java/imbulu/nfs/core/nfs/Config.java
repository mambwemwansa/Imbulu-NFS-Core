package imbulu.nfs.core.nfs;

import java.util.HashMap;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("nfs.service")
@Configuration
public class Config {
	private String tablename;

	private String packagerconfig;

	private String ip;

	private String port;

	private String timeout;

	private String echointerval;

	private int threadsize;

	private String signonwait;

	private String loggername;

	private boolean keepalive;

	private boolean expectkeepalive;

	private String cpgpaymenturl;

	private String cpgvalidationurl;

	private String cpgpaymentwrapperurl;

	private String outgoingresponseurl;

	private String cpgpostpaymentfunction;

	private String cpgpostpaymentackfunction;

	private String cpgvalidateaccountfunction;

	private String cpgfetchpaymentsfunction;

	private String currencycode;

	private String nfsusername;

	private String nfspassword;

	private String partnerusername;

	private String partnerpassword;

	private String isoheader;

	private int httptimeout;

	private String countrycode;

	private String institutionid;

	private String payerclientcode;

	private String intcurrencycode;

	private String isocurrencycode;

	private int cpgauthsuccess;

	private int cpgvalidatesuccess;

	private String addresstag;

	private String nametag;

	private String otptag;

	private HashMap<String, String> incomingInstitutionIDToServiceIDMap;

	private HashMap<String, String> incomingInstitutionIDToServiceCodeMap;

	private HashMap<Integer, String> outgoingServiceIDToInstitutionIDMap;

	private String field54;

	private String field93;

	private String txnsuccess;

	private String invalidaccount;

	private String donothonour;

	private String txntimeout;

	private String errorcode;

	private String failedreversal;

	private String invalidreversal;

	private String successreversal;

	private String errormessage;

	private int cpgpostpaymentsuccess;

	private int cpgpostpaymentacksuccess;

	private int cpgpostpaymentackressuccess;

	private int cpgpostpaymentackfailed;

	private int fetchlimit;

	private int cpgfetchpaymentsuccess;

	private String posdatacode;

	private String cardacceptorcode;

	private String cardacceptorterminalid;

	private String cardacceptoridcode;

	private String functioncode;

	private String ftmti;

	private String reversalmti;

	private String repeatreversalmti;

	private String biprocode;

	private String ftprocode;

	private String cwdprocode;

	private int outgoingwaittime;

	private int outgoingloopwait;

	private HashMap<String, String> validatemsisdncountrycode;

	private int indexControl;

	private HashMap<String, String> nfsnetwork;

	private Integer maxPoolSize;

	private Integer corePoolSize;

	private Integer msisdnLength;

	private String countryMsisdnPrefix;

	private HashMap<String, String> customConfig;

	private HashMap<String, String> nfsTransactionStatuses;

	public HashMap<String, String> getNfsTransactionStatuses() {
		return this.nfsTransactionStatuses;
	}

	public void setNfsTransactionStatuses(HashMap<String, String> nfsTransactionStatuses) {
		this.nfsTransactionStatuses = nfsTransactionStatuses;
	}

	public HashMap<String, String> getCustomConfig() {
		return this.customConfig;
	}

	public void setCustomConfig(HashMap<String, String> customConfig) {
		this.customConfig = customConfig;
	}

	public Integer getMsisdnLength() {
		return this.msisdnLength;
	}

	public void setMsisdnLength(Integer msisdnLength) {
		this.msisdnLength = msisdnLength;
	}

	public String getCountryMsisdnPrefix() {
		return this.countryMsisdnPrefix;
	}

	public void setCountryMsisdnPrefix(String countryMsisdnPrefix) {
		this.countryMsisdnPrefix = countryMsisdnPrefix;
	}

	public String getTablename() {
		return this.tablename;
	}

	public void setTablename(String tablename) {
		this.tablename = tablename;
	}

	public String getPackagerconfig() {
		return this.packagerconfig;
	}

	public void setPackagerconfig(String packagerconfig) {
		this.packagerconfig = packagerconfig;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getPort() {
		return this.port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getTimeout() {
		return this.timeout;
	}

	public void setTimeout(String timeout) {
		this.timeout = timeout;
	}

	public String getEchointerval() {
		return this.echointerval;
	}

	public void setEchointerval(String echointerval) {
		this.echointerval = echointerval;
	}

	public int getThreadsize() {
		return this.threadsize;
	}

	public void setThreadsize(int threadsize) {
		this.threadsize = threadsize;
	}

	public String getSignonwait() {
		return this.signonwait;
	}

	public void setSignonwait(String signonwait) {
		this.signonwait = signonwait;
	}

	public String getLoggername() {
		return this.loggername;
	}

	public void setLoggername(String loggername) {
		this.loggername = loggername;
	}

	public boolean isKeepalive() {
		return this.keepalive;
	}

	public void setKeepalive(boolean keepalive) {
		this.keepalive = keepalive;
	}

	public boolean isExpectkeepalive() {
		return this.expectkeepalive;
	}

	public void setExpectkeepalive(boolean expectkeepalive) {
		this.expectkeepalive = expectkeepalive;
	}

	public String getCpgpaymenturl() {
		return this.cpgpaymenturl;
	}

	public void setCpgpaymenturl(String cpgpaymenturl) {
		this.cpgpaymenturl = cpgpaymenturl;
	}

	public String getCpgvalidationurl() {
		return this.cpgvalidationurl;
	}

	public void setCpgvalidationurl(String cpgvalidationurl) {
		this.cpgvalidationurl = cpgvalidationurl;
	}

	public String getCpgpaymentwrapperurl() {
		return this.cpgpaymentwrapperurl;
	}

	public void setCpgpaymentwrapperurl(String cpgpaymentwrapperurl) {
		this.cpgpaymentwrapperurl = cpgpaymentwrapperurl;
	}

	public String getOutgoingresponseurl() {
		return this.outgoingresponseurl;
	}

	public void setOutgoingresponseurl(String outgoingresponseurl) {
		this.outgoingresponseurl = outgoingresponseurl;
	}

	public String getCpgpostpaymentfunction() {
		return this.cpgpostpaymentfunction;
	}

	public void setCpgpostpaymentfunction(String cpgpostpaymentfunction) {
		this.cpgpostpaymentfunction = cpgpostpaymentfunction;
	}

	public String getCpgpostpaymentackfunction() {
		return this.cpgpostpaymentackfunction;
	}

	public void setCpgpostpaymentackfunction(String cpgpostpaymentackfunction) {
		this.cpgpostpaymentackfunction = cpgpostpaymentackfunction;
	}

	public String getCpgvalidateaccountfunction() {
		return this.cpgvalidateaccountfunction;
	}

	public void setCpgvalidateaccountfunction(String cpgvalidateaccountfunction) {
		this.cpgvalidateaccountfunction = cpgvalidateaccountfunction;
	}

	public String getCpgfetchpaymentsfunction() {
		return this.cpgfetchpaymentsfunction;
	}

	public void setCpgfetchpaymentsfunction(String cpgfetchpaymentsfunction) {
		this.cpgfetchpaymentsfunction = cpgfetchpaymentsfunction;
	}

	public String getCurrencycode() {
		return this.currencycode;
	}

	public void setCurrencycode(String currencycode) {
		this.currencycode = currencycode;
	}

	public String getNfsusername() {
		return this.nfsusername;
	}

	public void setNfsusername(String nfsusername) {
		this.nfsusername = nfsusername;
	}

	public String getNfspassword() {
		return this.nfspassword;
	}

	public void setNfspassword(String nfspassword) {
		this.nfspassword = nfspassword;
	}

	public String getPartnerusername() {
		return this.partnerusername;
	}

	public void setPartnerusername(String partnerusername) {
		this.partnerusername = partnerusername;
	}

	public String getPartnerpassword() {
		return this.partnerpassword;
	}

	public void setPartnerpassword(String partnerpassword) {
		this.partnerpassword = partnerpassword;
	}

	public String getIsoheader() {
		return this.isoheader;
	}

	public void setIsoheader(String isoheader) {
		this.isoheader = isoheader;
	}

	public int getHttptimeout() {
		return this.httptimeout;
	}

	public void setHttptimeout(int httptimeout) {
		this.httptimeout = httptimeout;
	}

	public String getCountrycode() {
		return this.countrycode;
	}

	public void setCountrycode(String countrycode) {
		this.countrycode = countrycode;
	}

	public String getInstitutionid() {
		return this.institutionid;
	}

	public void setInstitutionid(String institutionid) {
		this.institutionid = institutionid;
	}

	public String getPayerclientcode() {
		return this.payerclientcode;
	}

	public void setPayerclientcode(String payerclientcode) {
		this.payerclientcode = payerclientcode;
	}

	public String getIntcurrencycode() {
		return this.intcurrencycode;
	}

	public void setIntcurrencycode(String intcurrencycode) {
		this.intcurrencycode = intcurrencycode;
	}

	public String getIsocurrencycode() {
		return this.isocurrencycode;
	}

	public void setIsocurrencycode(String isocurrencycode) {
		this.isocurrencycode = isocurrencycode;
	}

	public int getCpgauthsuccess() {
		return this.cpgauthsuccess;
	}

	public void setCpgauthsuccess(int cpgauthsuccess) {
		this.cpgauthsuccess = cpgauthsuccess;
	}

	public int getCpgvalidatesuccess() {
		return this.cpgvalidatesuccess;
	}

	public void setCpgvalidatesuccess(int cpgvalidatesuccess) {
		this.cpgvalidatesuccess = cpgvalidatesuccess;
	}

	public String getAddresstag() {
		return this.addresstag;
	}

	public void setAddresstag(String addresstag) {
		this.addresstag = addresstag;
	}

	public String getNametag() {
		return this.nametag;
	}

	public void setNametag(String nametag) {
		this.nametag = nametag;
	}

	public String getOtptag() {
		return this.otptag;
	}

	public void setOtptag(String otptag) {
		this.otptag = otptag;
	}

	public HashMap<String, String> getIncomingInstitutionIDToServiceIDMap() {
		return this.incomingInstitutionIDToServiceIDMap;
	}

	public void setIncomingInstitutionIDToServiceIDMap(HashMap<String, String> incomingInstitutionIDToServiceIDMap) {
		this.incomingInstitutionIDToServiceIDMap = incomingInstitutionIDToServiceIDMap;
	}

	public HashMap<String, String> getIncomingInstitutionIDToServiceCodeMap() {
		return this.incomingInstitutionIDToServiceCodeMap;
	}

	public void setIncomingInstitutionIDToServiceCodeMap(
			HashMap<String, String> incomingInstitutionIDToServiceCodeMap) {
		this.incomingInstitutionIDToServiceCodeMap = incomingInstitutionIDToServiceCodeMap;
	}

	public HashMap<Integer, String> getOutgoingServiceIDToInstitutionIDMap() {
		return this.outgoingServiceIDToInstitutionIDMap;
	}

	public void setOutgoingServiceIDToInstitutionIDMap(HashMap<Integer, String> outgoingServiceIDToInstitutionIDMap) {
		this.outgoingServiceIDToInstitutionIDMap = outgoingServiceIDToInstitutionIDMap;
	}

	public String getField54() {
		return this.field54;
	}

	public void setField54(String field54) {
		this.field54 = field54;
	}

	public String getField93() {
		return this.field93;
	}

	public void setField93(String field93) {
		this.field93 = field93;
	}

	public String getTxnsuccess() {
		return this.txnsuccess;
	}

	public void setTxnsuccess(String txnsuccess) {
		this.txnsuccess = txnsuccess;
	}

	public String getInvalidaccount() {
		return this.invalidaccount;
	}

	public void setInvalidaccount(String invalidaccount) {
		this.invalidaccount = invalidaccount;
	}

	public String getDonothonour() {
		return this.donothonour;
	}

	public void setDonothonour(String donothonour) {
		this.donothonour = donothonour;
	}

	public String getTxntimeout() {
		return this.txntimeout;
	}

	public void setTxntimeout(String txntimeout) {
		this.txntimeout = txntimeout;
	}

	public String getErrorcode() {
		return this.errorcode;
	}

	public void setErrorcode(String errorcode) {
		this.errorcode = errorcode;
	}

	public String getFailedreversal() {
		return this.failedreversal;
	}

	public void setFailedreversal(String failedreversal) {
		this.failedreversal = failedreversal;
	}

	public String getInvalidreversal() {
		return this.invalidreversal;
	}

	public void setInvalidreversal(String invalidreversal) {
		this.invalidreversal = invalidreversal;
	}

	public String getSuccessreversal() {
		return this.successreversal;
	}

	public void setSuccessreversal(String successreversal) {
		this.successreversal = successreversal;
	}

	public String getErrormessage() {
		return this.errormessage;
	}

	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}

	public int getCpgpostpaymentsuccess() {
		return this.cpgpostpaymentsuccess;
	}

	public void setCpgpostpaymentsuccess(int cpgpostpaymentsuccess) {
		this.cpgpostpaymentsuccess = cpgpostpaymentsuccess;
	}

	public int getCpgpostpaymentacksuccess() {
		return this.cpgpostpaymentacksuccess;
	}

	public void setCpgpostpaymentacksuccess(int cpgpostpaymentacksuccess) {
		this.cpgpostpaymentacksuccess = cpgpostpaymentacksuccess;
	}

	public int getCpgpostpaymentackressuccess() {
		return this.cpgpostpaymentackressuccess;
	}

	public void setCpgpostpaymentackressuccess(int cpgpostpaymentackressuccess) {
		this.cpgpostpaymentackressuccess = cpgpostpaymentackressuccess;
	}

	public int getCpgpostpaymentackfailed() {
		return this.cpgpostpaymentackfailed;
	}

	public void setCpgpostpaymentackfailed(int cpgpostpaymentackfailed) {
		this.cpgpostpaymentackfailed = cpgpostpaymentackfailed;
	}

	public int getFetchlimit() {
		return this.fetchlimit;
	}

	public void setFetchlimit(int fetchlimit) {
		this.fetchlimit = fetchlimit;
	}

	public int getCpgfetchpaymentsuccess() {
		return this.cpgfetchpaymentsuccess;
	}

	public void setCpgfetchpaymentsuccess(int cpgfetchpaymentsuccess) {
		this.cpgfetchpaymentsuccess = cpgfetchpaymentsuccess;
	}

	public String getPosdatacode() {
		return this.posdatacode;
	}

	public void setPosdatacode(String posdatacode) {
		this.posdatacode = posdatacode;
	}

	public String getCardacceptorcode() {
		return this.cardacceptorcode;
	}

	public void setCardacceptorcode(String cardacceptorcode) {
		this.cardacceptorcode = cardacceptorcode;
	}

	public String getCardacceptorterminalid() {
		return this.cardacceptorterminalid;
	}

	public void setCardacceptorterminalid(String cardacceptorterminalid) {
		this.cardacceptorterminalid = cardacceptorterminalid;
	}

	public String getCardacceptoridcode() {
		return this.cardacceptoridcode;
	}

	public void setCardacceptoridcode(String cardacceptoridcode) {
		this.cardacceptoridcode = cardacceptoridcode;
	}

	public String getFunctioncode() {
		return this.functioncode;
	}

	public void setFunctioncode(String functioncode) {
		this.functioncode = functioncode;
	}

	public String getFtmti() {
		return this.ftmti;
	}

	public void setFtmti(String ftmti) {
		this.ftmti = ftmti;
	}

	public String getReversalmti() {
		return this.reversalmti;
	}

	public void setReversalmti(String reversalmti) {
		this.reversalmti = reversalmti;
	}

	public String getRepeatreversalmti() {
		return this.repeatreversalmti;
	}

	public void setRepeatreversalmti(String repeatreversalmti) {
		this.repeatreversalmti = repeatreversalmti;
	}

	public String getBiprocode() {
		return this.biprocode;
	}

	public void setBiprocode(String biprocode) {
		this.biprocode = biprocode;
	}

	public String getFtprocode() {
		return this.ftprocode;
	}

	public void setFtprocode(String ftprocode) {
		this.ftprocode = ftprocode;
	}

	public String getCwdprocode() {
		return this.cwdprocode;
	}

	public void setCwdprocode(String cwdprocode) {
		this.cwdprocode = cwdprocode;
	}

	public int getOutgoingwaittime() {
		return this.outgoingwaittime;
	}

	public void setOutgoingwaittime(int outgoingwaittime) {
		this.outgoingwaittime = outgoingwaittime;
	}

	public int getOutgoingloopwait() {
		return this.outgoingloopwait;
	}

	public void setOutgoingloopwait(int outgoingloopwait) {
		this.outgoingloopwait = outgoingloopwait;
	}

	public HashMap<String, String> getValidatemsisdncountrycode() {
		return this.validatemsisdncountrycode;
	}

	public void setValidatemsisdncountrycode(HashMap<String, String> validatemsisdncountrycode) {
		this.validatemsisdncountrycode = validatemsisdncountrycode;
	}

	public int getIndexControl() {
		return indexControl;
	}

	public void setIndexControl(int indexControl) {
		this.indexControl = indexControl;
	}

	public HashMap<String, String> getNfsnetwork() {
		return this.nfsnetwork;
	}

	public void setNfsnetwork(HashMap<String, String> nfsnetwork) {
		this.nfsnetwork = nfsnetwork;
	}

	public Integer getMaxPoolSize() {
		return this.maxPoolSize;
	}

	public void setMaxPoolSize(Integer maxPoolSize) {
		this.maxPoolSize = maxPoolSize;
	}

	public Integer getCorePoolSize() {
		return this.corePoolSize;
	}

	public void setCorePoolSize(Integer corePoolSize) {
		this.corePoolSize = corePoolSize;
	}
}
