package imbulu.nfs.core.services;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClients;
import org.jpos.iso.ISODate;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOMsg;
import org.jpos.iso.ISOPackager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import imbulu.nfs.core.dao.ISOFieldsRepo;
import imbulu.nfs.core.nfs.Config;
import imbulu.nfs.core.pojos.ISOFields;
import imbulu.nfs.core.pojos.NFSTransfer;
import imbulu.nfs.core.services.Utils;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;

@Service
public class ISOService {
	private static final Logger logger = LoggerFactory.getLogger(imbulu.nfs.core.services.ISOService.class);
	@Autowired
	private Utils utils;

	@Value("${zm.co.fnb.nfs.base_URL}")
	private String base_URL;
	@Value("${zm.co.fnb.nfs.isolog}")
	private boolean isolog;

	@Autowired
	ISOFieldsRepo iSOFieldsRepo;

	public byte[] build(ISOMsg request) {
		byte[] data = null;
		try {
			request=this.utils.clean(request);
			request.setPackager((ISOPackager) this.utils.getIsopackager());
			data = request.pack();
			logger.info(this.utils.logISOMsg(request));
			if (isolog) {
				request.dump(System.out, "");
			}
		} catch (ISOException e) {
			logger.error("We have the following exceptions {}", e.getLocalizedMessage());
		}
		return data;
	}

	public void sendHTTPIncoming(ISOMsg request, String url) {
		logger.info("INCOMING HTTP REQUEST");
		logger.info("FORWARDING HTTP REQUEST URL:" + url);
		Map<String, String> headers = new HashMap<>();
		headers.put("Content-Type", "application/json");
		String json_request = utils.createRestISO(request);
		logger.info("[INCOMING FORWARDING JSON STRING] :" + json_request);
		try {
			Unirest.post(base_URL + url).headers(headers).body(json_request).asJsonAsync(send_response -> {
				logger.info("[INCOMING FORWARDING RESPONSE STATUS] :" + String.valueOf(send_response.getStatus()));
				logger.info("[INCOMING FORWARDING RESPONSE BODY] :" + send_response.getBody().toString());
				logger.info("[INCOMING FORWARDING RESPONSE TIMESTAMP] :" + new Timestamp(System.currentTimeMillis()));		        	        
		    });;

		} catch (Exception e) {
			logger.error("[INCOMING FORWARDING RESPONSE] :" + e.getMessage());
		}
	}

}
