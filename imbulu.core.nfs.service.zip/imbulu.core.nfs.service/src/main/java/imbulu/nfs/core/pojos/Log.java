package imbulu.nfs.core.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "iso_log")
public class Log {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id", insertable = false, updatable = false, nullable = false)
	String id;
	@Column(name="date", insertable = true, updatable = true, nullable = false)
	String date;
	@Column(name="data", insertable = true, updatable = true, nullable = false)
	String data;
	public Log() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Log(String id, String date, String data) {
		super();
		this.id = id;
		this.date = date;
		this.data = data;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "Log [id=" + id + ", date=" + date + ", data=" + data + "]";
	}
	
	
	
}
