package imbulu.nfs.core.client;


import org.jpos.core.Configuration;
import org.jpos.iso.ISOException;
import org.jpos.iso.packager.GenericPackager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class Packager {
  private static final Logger log = LoggerFactory.getLogger(imbulu.nfs.core.client.Packager.class);
  
  public GenericPackager getpackager(Configuration configuration) {
    GenericPackager genericPackager = null;
    try {
      genericPackager = new GenericPackager();
      genericPackager.setConfiguration(configuration);
    } catch (ISOException e) {
      log.error("We have the following exception " + e.getLocalizedMessage());
    } 
    return genericPackager;
  }
}
